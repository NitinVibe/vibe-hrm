import type { ReactNode } from "react";

type PageHeaderProps = {
  title: string;
  description?: string;
  actions?: ReactNode;
};

export default function PageHeader({
  title,
  description,
  actions,
}: PageHeaderProps) {
  return (
    <div className="vibe-page-header">
      <div>
        <div className="vibe-page-eyebrow">VIBE HRM</div>
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>

      {actions && <div className="vibe-page-actions">{actions}</div>}
    </div>
  );
}
