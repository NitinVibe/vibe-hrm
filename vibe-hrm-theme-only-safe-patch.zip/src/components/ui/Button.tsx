import type { ButtonHTMLAttributes, ReactNode } from "react";

type ButtonVariant =
  | "primary"
  | "secondary"
  | "outline"
  | "danger"
  | "ghost";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  children: ReactNode;
  variant?: ButtonVariant;
};

const variants: Record<ButtonVariant, string> = {
  primary: "vibe-button vibe-button-primary",
  secondary: "vibe-button vibe-button-secondary",
  outline: "vibe-button vibe-button-outline",
  danger: "vibe-button vibe-button-danger",
  ghost: "vibe-button vibe-button-ghost",
};

export default function Button({
  children,
  variant = "primary",
  className = "",
  ...props
}: ButtonProps) {
  return (
    <button {...props} className={`${variants[variant]} ${className}`}>
      {children}
    </button>
  );
}
