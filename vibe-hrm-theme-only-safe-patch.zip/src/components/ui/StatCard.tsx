import type { ElementType } from "react";
import Card from "./Card";

type StatCardProps = {
  title: string;
  value: string | number;
  description?: string;
  icon: ElementType;
};

export default function StatCard({
  title,
  value,
  description,
  icon: Icon,
}: StatCardProps) {
  return (
    <Card className="vibe-stat-card">
      <div className="vibe-stat-top">
        <div>
          <p className="vibe-stat-title">{title}</p>
          <p className="vibe-stat-value">{value}</p>
        </div>

        <div className="vibe-stat-icon">
          <Icon size={19} strokeWidth={1.8} />
        </div>
      </div>

      {description && <p className="vibe-stat-description">{description}</p>}
    </Card>
  );
}
