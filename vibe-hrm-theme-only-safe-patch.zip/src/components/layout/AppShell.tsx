import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import Header from "./Header";

export default function AppShell() {
  return (
    <div className="vibe-app-shell">
      <Sidebar />

      <div className="vibe-app-main">
        <Header />

        <main className="vibe-main-content">
          <div className="vibe-page-glow vibe-page-glow-one" />
          <div className="vibe-page-glow vibe-page-glow-two" />
          <div className="vibe-page-lines" />
          <div className="relative z-10">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
