import {
  Bell,
  ChevronDown,
  Grid2X2,
  HelpCircle,
  Plus,
  Search,
} from "lucide-react";
import { useLocation } from "react-router-dom";

type RoleInfo = {
  name: string;
  title: string;
  initial: string;
};

function getRoleInfo(pathname: string): RoleInfo {
  if (pathname.startsWith("/employee")) {
    return { name: "Employee", title: "Employee", initial: "E" };
  }

  if (pathname.startsWith("/manager")) {
    return { name: "Manager", title: "Manager", initial: "M" };
  }

  if (pathname.startsWith("/recruiter")) {
    return { name: "Recruiter", title: "Recruiter", initial: "R" };
  }

  if (pathname.startsWith("/payroll-admin")) {
    return {
      name: "Payroll Admin",
      title: "Payroll Administrator",
      initial: "P",
    };
  }

  return { name: "Admin", title: "Administrator", initial: "A" };
}

function getPageLabel(pathname: string) {
  if (pathname.startsWith("/people")) return "People";
  if (pathname.startsWith("/leads")) return "Leads";
  if (pathname.startsWith("/recruitment")) return "Recruitment";
  if (pathname.startsWith("/attendance")) return "Attendance & Time";
  if (pathname.startsWith("/leave")) return "Leave";
  if (pathname.startsWith("/payroll-admin")) return "Payroll Admin";
  if (pathname.startsWith("/payroll")) return "Payroll";
  if (pathname.startsWith("/performance")) return "Performance";
  if (pathname.startsWith("/projects")) return "Projects & Tasks";
  if (pathname.startsWith("/documents")) return "Documents";
  if (pathname.startsWith("/communication")) return "Communication";
  if (pathname.startsWith("/helpdesk")) return "Helpdesk";
  if (pathname.startsWith("/reports")) return "Reports";
  if (pathname.startsWith("/ai")) return "AI Assistant";
  if (pathname.startsWith("/admin")) return "Administration";
  if (pathname.startsWith("/employee")) return "Employee Portal";
  if (pathname.startsWith("/manager")) return "Manager Portal";
  if (pathname.startsWith("/recruiter")) return "Recruiter Portal";
  return "Dashboard";
}

export default function Header() {
  const location = useLocation();
  const role = getRoleInfo(location.pathname);
  const pageLabel = getPageLabel(location.pathname);

  return (
    <header className="vibe-header">
      <div className="vibe-header-left">
        <div className="vibe-breadcrumb">
          <span>Vibe HRM</span>
          <span className="vibe-breadcrumb-separator">/</span>
          <strong>{pageLabel}</strong>
        </div>

        <div className="vibe-search">
          <Search size={18} strokeWidth={1.8} />
          <input
            type="text"
            placeholder="Search employees, candidates, leave, payroll..."
            aria-label="Global search"
          />
          <kbd>Ctrl + K</kbd>
        </div>
      </div>

      <div className="vibe-header-actions">
        <button className="vibe-icon-button" aria-label="Quick add">
          <Plus size={19} strokeWidth={1.8} />
        </button>

        <button className="vibe-icon-button" aria-label="Help">
          <HelpCircle size={19} strokeWidth={1.8} />
        </button>

        <button className="vibe-icon-button vibe-notification-button" aria-label="Notifications">
          <Bell size={19} strokeWidth={1.8} />
          <span />
        </button>

        <button className="vibe-icon-button" aria-label="Applications">
          <Grid2X2 size={18} strokeWidth={1.8} />
        </button>

        <div className="vibe-header-divider" />

        <button className="vibe-user-menu">
          <div className="vibe-avatar">{role.initial}</div>
          <div className="vibe-user-copy">
            <strong>{role.name}</strong>
            <span>{role.title}</span>
          </div>
          <ChevronDown size={16} strokeWidth={1.8} />
        </button>
      </div>
    </header>
  );
}
