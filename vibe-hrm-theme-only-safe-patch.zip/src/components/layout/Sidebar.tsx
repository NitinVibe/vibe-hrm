import { useEffect, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  ChevronDown,
  ChevronRight,
  LayoutDashboard,
  Sparkles,
  Settings2,
} from "lucide-react";

import { getNavigationForRole } from "../../routes/roleNavigation";
import type { UserRole } from "../../routes/navigation";

function getRoleFromPath(pathname: string): UserRole {
  if (pathname.startsWith("/employee")) return "EMPLOYEE";
  if (pathname.startsWith("/manager")) return "MANAGER";
  if (pathname.startsWith("/recruiter")) return "RECRUITER";
  if (pathname.startsWith("/payroll-admin")) return "PAYROLL_ADMIN";
  return "ADMIN";
}

function getDashboardPath(role: UserRole): string {
  switch (role) {
    case "EMPLOYEE":
      return "/employee";
    case "MANAGER":
      return "/manager";
    case "RECRUITER":
      return "/recruiter";
    case "PAYROLL_ADMIN":
      return "/payroll-admin";
    default:
      return "/";
  }
}

function getSectionName(label: string) {
  const workforce = ["People", "Attendance & Time", "Leave"];
  const talent = ["Leads", "Recruitment"];
  const operations = ["Projects & Tasks", "Documents", "Communication", "Helpdesk"];
  const insights = ["Reports", "AI Assistant"];
  const administration = ["Organization", "Administration", "Settings"];

  if (workforce.includes(label)) return "WORKFORCE";
  if (talent.includes(label)) return "TALENT";
  if (operations.includes(label)) return "OPERATIONS";
  if (insights.includes(label)) return "REPORTS & INSIGHTS";
  if (administration.includes(label)) return "ADMINISTRATION";
  return "MODULES";
}

export default function Sidebar() {
  const location = useLocation();
  const role = getRoleFromPath(location.pathname);
  const navigation = getNavigationForRole(role);
  const dashboardPath = getDashboardPath(role);

  const activeGroup = navigation.find((group) =>
    group.items.some(
      (item) =>
        location.pathname === item.path ||
        location.pathname.startsWith(`${item.path}/`),
    ),
  )?.label ?? null;

  const [openGroup, setOpenGroup] = useState<string | null>(activeGroup);

  useEffect(() => {
    if (activeGroup) setOpenGroup(activeGroup);
  }, [activeGroup]);

  let currentSection = "";

  return (
    <aside className="vibe-sidebar">
      <div className="vibe-brand">
        <div className="vibe-brand-mark">V</div>
        <div className="vibe-brand-copy">
          <strong>Vibe HRM</strong>
          <span>Human Resources</span>
        </div>
        <button className="vibe-brand-switch" aria-label="Switch organization">
          <ChevronDown size={15} />
        </button>
      </div>

      <div className="vibe-sidebar-divider" />

      <nav className="vibe-sidebar-nav">
        <NavLink
          to={dashboardPath}
          end
          className={({ isActive }) =>
            `vibe-nav-dashboard ${isActive ? "is-active" : ""}`
          }
        >
          <LayoutDashboard size={17} strokeWidth={1.8} />
          <span>Dashboard</span>
        </NavLink>

        <div className="vibe-nav-groups">
          {navigation.map((group) => {
            const Icon = group.icon;
            const section = getSectionName(group.label);
            const showSection = section !== currentSection;
            currentSection = section;
            const isOpen = openGroup === group.label;

            return (
              <div key={group.label}>
                {showSection && <div className="vibe-nav-section">{section}</div>}

                <div className={`vibe-nav-group ${isOpen ? "is-open" : ""}`}>
                  <button
                    type="button"
                    className="vibe-nav-group-button"
                    onClick={() =>
                      setOpenGroup(isOpen ? null : group.label)
                    }
                  >
                    <span>
                      <Icon size={17} strokeWidth={1.75} />
                      {group.label}
                    </span>
                    {isOpen ? (
                      <ChevronDown size={15} strokeWidth={1.8} />
                    ) : (
                      <ChevronRight size={15} strokeWidth={1.8} />
                    )}
                  </button>

                  <div className={`vibe-nav-items ${isOpen ? "is-visible" : ""}`}>
                    {group.items.map((item) => {
                      const ItemIcon = item.icon;

                      return (
                        <NavLink
                          key={item.path}
                          to={item.path}
                          className={({ isActive }) =>
                            `vibe-nav-item ${isActive ? "is-active" : ""}`
                          }
                        >
                          <ItemIcon size={14} strokeWidth={1.7} />
                          <span>{item.label}</span>
                        </NavLink>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </nav>

      <div className="vibe-sidebar-bottom">
        <NavLink to="/admin/system" className="vibe-settings-link">
          <Settings2 size={17} strokeWidth={1.8} />
          <span>Settings</span>
        </NavLink>

        <div className="vibe-sidebar-promo">
          <div className="vibe-sidebar-promo-icon">
            <Sparkles size={16} strokeWidth={1.8} />
          </div>
          <div>
            <strong>Vibe HRM</strong>
            <span>Enterprise HR Platform</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
